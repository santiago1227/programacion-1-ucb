// Clase Pasajero
class Pasajero {
    constructor(nombre, edad, genero, tipoBoleto) {
        this.nombre = nombre;
        this.edad = edad;
        this.genero = genero;
        this.tipoBoleto = tipoBoleto;
    }

    toString() {
        return `${this.nombre} (${this.genero}, ${this.edad} años, ${this.tipoBoleto})`;
    }
}

// Clase Bote de Rescate
class BoteRescate {
    constructor(nombre, capacidadMaxima) {
        this.nombre = nombre;
        this.capacidadMaxima = capacidadMaxima;
        this.ocupantes = [];
    }

    agregarPasajero(pasajero) {
        if (this.ocupantes.length < this.capacidadMaxima) {
            this.ocupantes.push(pasajero);
            return true;
        }
        return false;
    }

    mostrarOcupantes() {
        if (this.ocupantes.length === 0) return `${this.nombre} está vacío.`;
        return `<strong>${this.nombre}</strong> (${this.ocupantes.length}/${this.capacidadMaxima})<br>` +
               this.ocupantes.map(p => `- ${p.toString()}`).join("<br>");
    }
}

// Función de evacuación
function evacuar(pasajeros, botes) {
    // Criterio: mujeres y niños (<12 años) primero
    pasajeros.sort((a, b) => {
        if (a.genero === "Femenino" && b.genero !== "Femenino") return -1;
        if (a.genero !== "Femenino" && b.genero === "Femenino") return 1;
        if (a.edad < 12 && b.edad >= 12) return -1;
        if (a.edad >= 12 && b.edad < 12) return 1;
        return 0;
    });

    const noEvacuados = [];

    for (let pasajero of pasajeros) {
        let asignado = false;
        for (let bote of botes) {
            if (bote.agregarPasajero(pasajero)) {
                asignado = true;
                break;
            }
        }
        if (!asignado) noEvacuados.push(pasajero);
    }

    return { botes, noEvacuados };
}

// Simulación
function simularEvacuacion() {
    const pasajeros = [
        new Pasajero("Ana", 25, "Femenino", "1ra Clase"),
        new Pasajero("Luis", 34, "Masculino", "2da Clase"),
        new Pasajero("María", 10, "Femenino", "3ra Clase"),
        new Pasajero("Pedro", 8, "Masculino", "2da Clase"),
        new Pasajero("Sofía", 60, "Femenino", "1ra Clase"),
        new Pasajero("Carlos", 45, "Masculino", "1ra Clase"),
        new Pasajero("Lucía", 30, "Femenino", "2da Clase"),
        new Pasajero("Miguel", 20, "Masculino", "3ra Clase"),
        new Pasajero("Valeria", 5, "Femenino", "3ra Clase"),
        new Pasajero("Jorge", 50, "Masculino", "2da Clase")
    ];

    const botes = [
        new BoteRescate("Bote A", 4),
        new BoteRescate("Bote B", 3),
        new BoteRescate("Bote C", 2)
    ];

    const resultado = evacuar(pasajeros, botes);

    // Mostrar en pantalla
    let salida = "<h3>Resultados de la Evacuación</h3>";

    resultado.botes.forEach(bote => {
        salida += `<p>${bote.mostrarOcupantes()}</p>`;
    });

    if (resultado.noEvacuados.length > 0) {
        salida += "<h4>Pasajeros que quedaron fuera:</h4>";
        salida += resultado.noEvacuados.map(p => `- ${p.toString()}`).join("<br>");
    } else {
        salida += "<p>¡Todos fueron evacuados!</p>";
    }

    document.getElementById("resultado").innerHTML = salida;
}
